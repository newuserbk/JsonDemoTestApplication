package com.project.testFramework;

import static com.jayway.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.project.demo.HelperFunctions;
import com.project.demo.JsonHandler;
import com.project.framework.Resources;

public class GetAllUsers extends BasePage {

	
	
// Below Test Method for Print Data as per below mentioned request
	//Read assigned Seller-Json.json file
	//Print the value of addressLine1
	//Print value of all phone numbers
	//Print total jurisdiction count
	//Print all -> jurisdiction value along with its isVISACountries, ecl, importRegime count and taxoffice name value
	//Replace visaRegistrationDate for all jurisdiction as today’s date in the same file. No need to create a new file.
	//Check if file name is having hybrid word or not and print the message accordingly.
	//Reduce registrationDate by 1 month. Same as above, it should happen in the same file.
	//Print Amazon Seller key
	@Test
	public void printJsonData() {
		String filePath = "src/test/resources/Seller-Json.json";

		try {
			JsonHandler.printAddressLine1Value(filePath);
			JsonHandler.printAllPhoneNumbers(filePath);
			JsonHandler.getJurisdictionInfoAndupdateJsonFile(filePath);
			if (HelperFunctions.getFileName(filePath).contains("hybrid")) {
				System.out.println("File name is having the word hybrid.");
			} else {
				System.out.println("File name is not having the word hybrid");
			}
			JsonHandler.printAmzonSellerKey(filePath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//This is the test method written for rest assured.
	// Here taken demo API -http://restapi.demoqa.com/utilities/weather/city where i am trying to display data
		@Test
		public void getAllUsers() {
			Response res = given().header("Content-Type", "application/json").when().get(Resources.placeGetUsers()).then()
					.assertThat().statusCode(200).log().all().and().contentType(ContentType.JSON).and().extract()
					.response();
			String responseString = res.asString();
			System.out.println(responseString);

		}
		
	
}