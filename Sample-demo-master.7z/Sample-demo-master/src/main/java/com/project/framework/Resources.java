package com.project.framework;

public class Resources {

	public static String placeGetUsers() {

		String res = "/Hyderabad";
		return res;
	}
}