package com.project.framework;


public class PayLoad {
	public static String getPost()
	{
	
		String b = "{"+ "\"username\" : \"xxx\","+ "\"password\" : \"xxx\""+"}";
		return b;
	}
}